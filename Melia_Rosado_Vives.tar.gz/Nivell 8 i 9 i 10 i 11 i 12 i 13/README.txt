Grupo: Cristo Rey 2
Miembros: Marc Melià Flexas
					Pau Rosado Muñoz
					Xavier Vives Marcus

Mejoras realizadas:
De la tercera entrega ninguna. Las mejoras realizadas ya han sido evaluadas.