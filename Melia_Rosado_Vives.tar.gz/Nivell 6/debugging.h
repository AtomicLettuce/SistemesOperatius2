#define DEBUGN2 0
#define DEBUGN3 0
#define DEBUGN4 1
#define DEBUGN5 0
#define DEBUGN6 1
#define DEBUGN7 1
#define DEBUGN8 1
#define DEBUGN9 1
#define DEBUGN10 1
#define DEBUGN11 1
#define DEBUGN12 1
#define DEBUGN13 1

#define DEBUGN41 0
